// script.js
const basket = [];
const basketCount = document.getElementById('basketCount');
const basketList = document.getElementById('basketList');
const totalAmount = document.getElementById('totalAmount');

document.querySelectorAll('.add-to-basket').forEach(button => {
  button.addEventListener('click', (e) => {
    const name = e.target.dataset.name;
    const price = parseInt(e.target.dataset.price);
    basket.push({ name, price });
    updateBasket();
  });
});

function updateBasket() {
  basketCount.innerText = basket.length;
  basketList.innerHTML = '';
  let total = 0;
  basket.forEach(item => {
    const li = document.createElement('li');
    li.innerText = `${item.name} - ₹${item.price}`;
    basketList.appendChild(li);
    total += item.price;
  });
  totalAmount.innerText = total;
}

document.getElementById('checkoutBtn').addEventListener('click', () => {
  alert('Proceeding to payment...');
});

const sections = document.querySelectorAll('.form-section, .basket-section');
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    sections.forEach(section => section.style.display = 'none');
    const target = e.target.getAttribute('href').substring(1);
    document.getElementById(target).style.display = 'block';
  });
});
